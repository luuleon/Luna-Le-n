#include <iostream>
#include <cmath>
using namespace std;

bool estaEnArreglo(int arreglo[], int tamaño, int valor) {
    for (int i = 0; i < tamaño; i++) {
        if (arreglo[i] == valor) {
            return true;
        }
    }
    return false;
}


int calcularSumaCubo(int numero) {
    int suma = 0;
    while (numero > 0) {
        int digito = numero % 10;
        suma += pow(digito, 3);
        numero /= 10;
    }
    return suma;
}

void verificarCubinfinito(int cubinfinitos[], int contadorCifras) {
    if (cubinfinitos[contadorCifras] == 1) {
        cout << "El número es cubinfinito" << endl;
    } else {
        cout << "El número no es cubinfinito" << endl;
    }
}

int main() {
    int numeroInicial;
    cout << "Ingrese un número: ";
    cin >> numeroInicial;
    int contador = 0;
    int cubinfinitos[100]; 
    cubinfinitos[contador] = numeroInicial;
    int valor = numeroInicial;
    while (true) {
        int siguienteValor = calcularSumaCubo(valor);
        if (estaEnArreglo(cubinfinitos, contador + 1, siguienteValor)) {
            break;
        }
        contador++;
        cubinfinitos[contador] = siguienteValor;
        valor = siguienteValor;
    }
    for (int i = 0; i <= contador; i++) {
        cout << cubinfinitos[i] << " ";
    }
    verificarCubinfinito(cubinfinitos, contador);
    cout << endl;
    return 0;
}
