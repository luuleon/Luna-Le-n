#include <iostream>
using namespace std;
void sacarGente(int cantidad, int numeros[], int retiradoFila[], int &contador)
{ 
    for (int i = 0; i < cantidad; i++)
    {
        if (i < cantidad - 1 && numeros[i] > numeros[i + 1])
        {
            retiradoFila[contador] = numeros[i];
            contador++;
        }
    }
}

int main()
{
    int cantidad, contador = 0;
    cout << "Ingrese cantidad de usuarios en la fila: ";
    cin >> cantidad;

    int numeros[cantidad];
    cout << "Ingrese los numeros: ";
    for (int i = 0; i < cantidad; i++)
    {
        cin >> numeros[i];
    }

    int retiradoFila[cantidad];
    sacarGente(cantidad, numeros, retiradoFila, contador);

    cout << "Cantidad de numeros retirados: " << contador << endl;
    cout << "Numeros retirados: ";
    for (int i = 0; i < contador; i++)
    {
        cout << retiradoFila[i] << " ";
    }
    cout << endl;

    return 0;
}
