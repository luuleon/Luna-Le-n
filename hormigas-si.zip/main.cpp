#include <iostream>
using namespace std;

bool armarSandwich(int numCortezas, int sandwich[]) {
    for (int i = 0; i < numCortezas; i++) {
        int suma = 0;
        for (int j = i + 1; j < numCortezas; j++) {
            suma += sandwich[j];
            if (suma == sandwich[i]) {
                cout << i + 1 << endl;
                return true;
            }
        }
    }
    return false;
}

int main() {
    int numCortezas;
    cout << "Cantidad de cortezas (máximo 100): ";
    cin >> numCortezas;

    int sandwich[numCortezas];
    for (int i = 0; i < numCortezas; i++) {
        cout << "Valor de la corteza " << i + 1 << ": ";
        cin >> sandwich[i];
    }

    if (armarSandwich(numCortezas, sandwich)) {
        cout << "SI" << endl;
    } else {
        cout << "NO" << endl;
    }
    return 0;
}

