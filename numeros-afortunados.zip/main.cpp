#include <iostream>
using namespace std;

void numerosAfortunados(int numero){
    int afortunados1[100];
    int afortunados2[100];
    int k=1, h=2, cantidad;
    bool mayor;
    for (int i=0; i<100; i++){
        afortunados2[i]=-1;
        afortunados1[i]=-1;
    }
    for (int i=0; i<numero; i++){
        afortunados1[i]=k;
        k++;
    }
    do{
        for (int i=0; i<100;){
            afortunados1[i]=-1;
            i+=h;
        }
        int m=0;
        for (int i=0; i<100; i++){
            if (afortunados1[i]!=-1){
                afortunados2[m]=afortunados1[i];
                m++;
            }
        }
        for (int i=0; i<100; i++){
            afortunados1[i]=afortunados2[i];
        }
        for (int i=0; i<100; i++){
            afortunados2[i]=-1;
        }
        cantidad=0;
        for (int i=0; i<100; i++){
            if (afortunados1[i]!=-1){
                cantidad++;
            }
        }
        if (h<=cantidad){
            mayor=true;
            h++;
        }
        if (h>cantidad){
            mayor=false;
        }
    } 
    while (mayor);
    cout << numero << ": ";
    for(int j=0; j<100; j++){
        if (afortunados1[j]!=-1){
            cout << afortunados1[j] << " ";
        }
    }
    cout << endl;
}
int main()
{
    setlocale(LC_ALL,"");
    int numero;
    while (true) {
        cout << "Ingrese un número entre 2 y 100 ( 0 para salir): ";
        cin >> numero;
        if (numero == 0) {
            break;
        }
        numerosAfortunados(numero);
    }
    return 0;
}